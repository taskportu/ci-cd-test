<?php

namespace Http\Adapter\Guzzle6\Exception;

use Http\Client\Exception;

final class UnexpectedValueException extends \UnexpectedValueException implements Exception
{
}
