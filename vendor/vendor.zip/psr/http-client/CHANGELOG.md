# Changelog

All notable changes to this project will be documented in this file, in reverse chronological order by release.

## 1.0.1

Allow installation with PHP 8. No code changes.

## 1.0.0

First stable release. No changes since 0.3.0.

## 0.3.0

Added Interface suffix on exceptions
 
## 0.2.0 

All exceptions are in `Psr\Http\Client` namespace

## 0.1.0

First release
