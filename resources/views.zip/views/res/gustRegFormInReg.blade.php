<div class="row mb-1 mt-1 gc-rgfp{{ $member->MemberID }}{{$unique}}" data-regfrom="{{$unique}}"> 
	<div class="col-12">
                <form class="input-group gc-rmgrf" data-member="{{ $member->MemberID }}" data-memberid="{{ $member->MemberID }}{{$unique}}">
                    <input type="hidden" name="member" value="{{ $member->MemberID }}" />
                    <input type="hidden" name="form" value="true" />
                    <datalist id="gc-grfcl" >
                    	 @foreach($club as $club)
            		<option value="{{ $club->ClubName }}">{{ $club->ClubName}}</option>
        			@endforeach
                        
                    </datalist>
                    <input type="text" disabled style="width:7%" placeholder="Gjest">
                    
                    <input type="text" class="form-control from_check" pattern=".*\S+.*" placeholder="Fornavn" required name="fistName">
                    <input type="text" class="form-control from_check" pattern=".*\S+.*" placeholder="Etternavn" required name="lastName">
					<input type="number" class="form-control from_check" placeholder="Mobil" name="phone">
                    <input type="text" class="form-control from_check" placeholder="Klubb navn" style="padding-left:5px;width:50px" autocomplete="off" name="club" list="gc-grfcl" placeholder="Club name">
                    <input type="text" class="form-control from_check" style="max-width:70px" placeholder="HCP" name="hcp">
                    <button class="btn btn-success gc-sm{{ $member->MemberID }}" type="submit">
                        <span class="gc-help"><span class="glyphicon glyphicon-ok"></span></span>
                    </button>
                    <button class="btn btn-danger"  type="button" data-id="{{$unique}}" onClick="remove_regfromgust(this)">
                        <span class="gc-help"><span class="glyphicon glyphicon-remove"></span></span>
                    </button>
                </form>
            </div>
        
</div>
