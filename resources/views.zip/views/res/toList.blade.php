<div class="row mb-1 pb-1" data-gcid="{{ $member['MemberID'] }}" id="notinsert">
	<input type="hidden" name="MemberID" value="{{ $member['MemberID'] }}"/>
    <input type="hidden" name="hcp" value="{{$member['HCP']}}">
	<div class="col-12">
    	<div class="mltr pt-1 pb-1">
            <div class="row">
                <div class="col-sm-9">
                    <div class="row">
                        <div class="col-2">{{ $member['OccID'] }}</div>
                        <div class="col-10">
                        	<div class="row">
                            	<div class="col-4">
                                	{{$member['Member_Fistname'] }} {{$member['Member_Lastname']}}
                                </div>
                                <div class="col-5 ">
                                    <span class="gc-st">{{ (!empty($member['new_club']) ? $member['new_club'] :'OCC-GOLF') }}</span>
                                </div>
                                <div class="col-3 text-right" >
                                    
                                    <button class="btn btn-success btn-sm" style="height:30px;width:41px; text-align:center"  data-memberid="{{$member['OccID']}}" id="hcpmodal">
                                        <span class="glyphicon glyphicon-pencil"></span>
                                    </button>
                                    {{-- <a href="#"  id="hcpmodal" data-hcp="{{ $member->HCP  }}">modal</a>--}}
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="row">
                    	<div class="col-8 " style="margin-right:-15px !important">
                            <span class="gc-hmb{{ $member['MemberID'] }} float-right">
                                <label for="gc-b{{ $member['MemberID'] }}" data-id="{{ $member['MemberID'] }}" class="gc-ibag">
                                    <span class="gc-help gc-help-light">
                                        <p class="text-center guest_name_update">Legg til<br>gjest!
                                        </p>
                                    </span>
                                </label>
                            </span>
                        </div>
                        <div class="col-4 gc-reg-marked text-right">
                            <button class="btn btn-danger" style="padding:5px 10px !important" type="button" >
                                <span class="gc-help">
                                    <span class="glyphicon glyphicon-trash pl-1" onclick="removegest({{ $member['MemberID'] }})"></span>
                                </span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12">
        <div class="row">
            <div class="col-12 gc-{{ $member['MemberID'] }}">
            </div>
        </div>
    </div>
</div>
