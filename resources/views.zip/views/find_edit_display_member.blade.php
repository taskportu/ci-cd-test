<div class="">


    <table class="table table-hover">
      <thead>
        <tr>
          
          <th scope="col">OccID</th>
          <th scope="col">MemberName</th>
          <th scope="col" >HCP</th>
          <th scope="col">Active</th>
          <th scope="col" class="text-left">Edit</th>
        </tr>
      </thead>
      <tbody>
        @foreach($members as $data)
        <tr id="{{$data->MemberID}}">
          
          <td>{{$data->OccID}}</td>
          <td>
          <span  class="{{$data->MemberID}}">
          {{$data->Member_Fistname}} {{$data->Member_Lastname}}
          </span>

         <input type="text"   data-fistname="{{$data->MemberID}}"
         value="{{$data->Member_Fistname}}" style="width:50%;display:none" 
          data-fistdieplayname="{{$data->Member_Fistname}}"> 
         <input type="text"   data-lastname="{{$data->MemberID}}"
         value="{{$data->Member_Lastname}}" style="width:48%;display:none"
          name="data-inputlastnamesave">
         </td>
          <td><span data-hcp="{{$data->MemberID}}"> {{ !empty($data->new_hcp) ? $data->new_hcp : $data->HCP  }}
          </span>
          <input type="text"   data-hcpinput="{{$data->MemberID}}"
         value="{{$data->HCP}}" style="width:38%;display:none;" name="data-inputsaveHcp"></td>
          <td align="center">
          	@if($data->Active==1 && $data->member_type != 'Passiv' && $data->member_type != 'Slettet')
              <button class="btn btn-success btn-sm"  data-active="active" 
            data-activestatusid="{{$data->MemberID}}" onClick="active_staus(this)">
                <span class="glyphicon glyphicon-off"></span>
               </button>
            @else
            <button class="btn btn-danger btn-sm"  data-active="inactive"
             data-activestatusid="{{$data->MemberID}}"  onClick="active_staus(this)">
          <span class="glyphicon glyphicon-off"></span>
          </button>
            @endif
          </td>
          <td align="right">
         <!--<button class="btn btn-success btn-sm"-->
         <!-- onClick="find_report_eit_member(this.id)"-->
         <!--  id="{{$data->MemberID}}" data-edit="{{$data->MemberID}}" data-active="none">-->
         <!--  <span class="glyphicon glyphicon-pencil"></span></button>-->
         <!-- <button  style="display:none" class="btn btn-success btn-sm" onClick="save_report_member(this.id)" id="{{$data->MemberID}}" data-save="{{$data->MemberID}}" ><span class="glyphicon glyphicon-floppy-disk"></span></button>-->
         <a href="{{ route('memberedits',$data->MemberID)}}">
            <button class="btn btn-success btn-sm" >
              <span class="glyphicon glyphicon-pencil"></span>
            </button>
               
          </a>
         
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>
</div>
