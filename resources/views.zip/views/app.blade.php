@extends('layout')
@section('home')
@push('link')
     {{-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <link rel="stylesheet" href="/app_calender/style.css">     --}}

        <style>
        @media only screen and (min-width: 600px) {
            .form {
                width: 50%;
                text-align: left;     
                margin-left: 25%;

                
            }
            .form2{
                width: 50%;
                text-align: left;     
                margin-left: 25%;
                right: 38px;
            }
            
            .logo_img{
                width:50%;
            }
            .select_club{
                width: 69%;
            }
        } 
        @media only screen and (min-width: 600px)
        {
            .form {
                width: 54% !important;
                text-align: left;
                margin-left: 25%;
            }
            .form2{
                width: 52% !important;
                text-align: left;
                margin-left: 0%;
               
            }
            .input_clas{
                /* margin-top: 15px !important; */
            }
        }
        .bg-dark {
            background-color: #002a71!important;
        }

        @media only screen 
        and (min-device-width: 768px) 
        and (max-device-width: 1024px) 
        and (-webkit-min-device-pixel-ratio: 2) {
            .form {
                width: 81% !important;
                text-align: left;
                margin-left: 25%;
            }
            .form2 {
                width: 80% !important;
                text-align: left;
                margin-left: 25%;
                
            }
            .input_clas{
                margin-top: 15px !important;
            }
            th{
                width: 21% !important;
            }
        }


        .navbar-dark .navbar-toggler {
            color: rgb(0, 42, 113);
            border-color: rgb(253, 253, 253);
        }
        th{
            width: 30%;
        }



        .navbar-dark .navbar-brand {
            color: #fff;
            font-family: sans-serif;
            font-size: 20px;
        }
      
        @media (min-width: 576px)
        {
            .labelname{
               
                max-width: 100% !important;
            }

           
        }

        @media only screen and (max-width: 600px) {
            th{
                width: 19% !important;
            }
            .th_class{
                 width: 49% !important;
            }
        }
        /* Radio button for manual online */
        .inputGroup22 {
  background-color: #d5d9e0;
  display: block;
  margin: 10px 0;
  position: relative;
}
.inputGroup22 label {
  padding: 12px 30px;
  width: auto;
  display: block;
  text-align: left;
  color: #3C454C;
  cursor: pointer;
  position: relative;
  z-index: 2;
  -webkit-transition: color 200ms ease-in;
  transition: color 200ms ease-in;
  overflow: hidden;
}
.inputGroup22 label:before {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  content: '';
  background-color: #002a71!important;
  position: absolute;
  left: 50%;
  top: 50%;
  -webkit-transform: translate(-50%, -50%) scale3d(1, 1, 1);
          transform: translate(-50%, -50%) scale3d(1, 1, 1);
  -webkit-transition: all 300ms cubic-bezier(0.4, 0, 0.2, 1);
  transition: all 300ms cubic-bezier(0.4, 0, 0.2, 1);
  opacity: 0;
  z-index: -1;
}
.inputGroup22 label:after {
  width: 32px;
  height: 32px;
  content: '';
  border: 2px solid #D1D7DC;
  background-color: #fff;
  background-image: url("data:image/svg+xml,%3Csvg width='32' height='32' viewBox='0 0 32 32' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M5.414 11L4 12.414l5.414 5.414L20.828 6.414 19.414 5l-10 10z' fill='%23fff' fill-rule='nonzero'/%3E%3C/svg%3E ");
  background-repeat: no-repeat;
  background-position: 2px 3px;
  border-radius: 50%;
  z-index: 2;
  position: absolute;
  right: 30px;
  top: 50%;
  -webkit-transform: translateY(-50%);
          transform: translateY(-50%);
  cursor: pointer;
  -webkit-transition: all 200ms ease-in;
  transition: all 200ms ease-in;
}
.inputGroup22 input:checked ~ label {
  color: #fff;
}
.inputGroup22 input:checked ~ label:before {
  -webkit-transform: translate(-50%, -50%) scale3d(56, 56, 1);
          transform: translate(-50%, -50%) scale3d(56, 56, 1);
  opacity: 1;
}
.inputGroup22 input:checked ~ label:after {
    background-color: #000000;
    border-color: #08ff3f;
}
.inputGroup22 input {
  width: 32px;
  height: 32px;
  -webkit-box-ordinal-group: 2;
          order: 1;
  z-index: 2;
  position: absolute;
  right: 30px;
  top: 50%;
  -webkit-transform: translateY(-50%);
          transform: translateY(-50%);
  cursor: pointer;
  visibility: hidden;
}

.form22 {
  padding: 0 16px;
  max-width: 550px;
  margin: 50px auto;
  font-size: 18px;
  font-weight: 600;
  line-height: 36px;
}

body {
  /* background-color: #D1D7DC; */
  font-family: 'Fira Sans', sans-serif;
}

*,
*::before,
*::after {
  box-sizing: inherit;
}

html {
  box-sizing: border-box;
}

code {
  background-color: #9AA3AC;
  padding: 0 8px;
}
        /* Radio button for manual online */
    </style>
    
@endpush
{{-- @push('link')
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  
@endpush
@push('script2')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
@endpush --}}
<div class="container-fluid">
	<div class="row">
    <div class="col-12 ">
   

  
 
 {{-- @if((Session::get('user')=='user') and (Session::get('authenticated')==''))
   
    <a href="{{ url('adminlogout') }}"  class="gc-help" >LOGOUT<!-- <span class="gc-sc"> (F5)</span>--></a></h3>
 @else --}}
 {{-- <h3> --}}
     {{-- <a href="{{ url('admin') }}"  class="gc-help" >ADMIN<!-- <span class="gc-sc"> (F5)</span>--></a>
    <span style="font-size: 15px;">|</span> --}}
    {{-- <a href="{{ url('applogout') }}"  class="gc-help" >LOGOUT<!-- <span class="gc-sc"> (F5)</span>--></a></h3> --}}

 {{-- @endif --}}
 
  
 
    <div class="container">
        @if(  !empty($validate) && $validate == "success_otp")

        <div class="row">
            <div class="col-12">
                <nav class="navbar bg-dark navbar-dark">
                    <a class="navbar-brand" href="#">OCC</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                      <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="collapsibleNavbar">
                      <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="{{url('app').'?name=front'}}">HJEM</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="{{url('app').'?name=card'}}">KORT</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="{{url('app').'?name=hcp'}}">HANDIKAP</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="{{url('app').'?name=info'}}">MEDLEMSINFO</a>
                        </li>   
                        <li class="nav-item">
                            <a class="nav-link" href="{{url('app').'?name=play'}}">FORHÅNDSMELDE</a>
                        </li>   
                        <li class="nav-item">
                            <a class="nav-link" href="{{url('app').'?name=play2'}}">TURNERING SPILL</a>
                        </li>    
                        <li class="nav-item">
                            <a class="nav-link" href="{{url('app').'?name=group'}}">SPILLGRUPPE</a>
                        </li>    
                        <li class="nav-item">
                            <a class="nav-link" href="{{url('app').'?name=setup'}}">INNSTILLINGER</a>
                        </li>  
                        <li class="nav-item">
                            <a class="nav-link" href="{{url('app').'?name=pay'}}">BETALING</a>
                        </li>  
                          
                        <li class="nav-item">
                            <a class="nav-link" href="{{ url('applogout') }}">LOGOUT</a>
                        </li>    
                      </ul>
                    </div>  
                  </nav>
            </div>
        </div>
        @endif
  

	<div class="row mb-2">
        @if ($parameter != "card")
    	<div class="col-12 p-3">
    		
    		<center>
                  <img class="img-fluid" src="../images/banner.jpg">
              </center>	
        </div>
        @endif
       

      
     
        {{-- <div class="row"> --}}
        <div class="col-12">
            
            {{-- {{$validate}} --}}
            @if(  !empty($validate) && $validate == "success_otp")
            <form id="update_form"style="border: 2px solid;" >
            @csrf
            <div class="row">
                <div class="col-md-12">
                    {{-- <nav>
                        <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home"
                                role="tab" aria-controls="nav-home" aria-selected="true">CARD</a>
                            <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile"
                                role="tab" aria-controls="nav-profile" aria-selected="false">HCP</a>
                            <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact"
                                role="tab" aria-controls="nav-contact" aria-selected="false">INFO</a>

                            <a class="nav-item nav-link" id="nav-contact-facility" data-toggle="tab" href="#nav-facility"
                                role="tab" aria-controls="nav-facility" aria-selected="false">PLAY</a>

                            <a class="nav-item nav-link" id="nav-contact-share" data-toggle="tab" href="#nav-share"
                                role="tab" aria-controls="nav-share" aria-selected="false">GROUP</a>

                            <a class="nav-item nav-link" id="nav-contact-setup" data-toggle="tab" href="#nav-setup"
                                role="tab" aria-controls="nav-setup" aria-selected="false">SETUP</a>
                        </div>
                    </nav> --}}
                    
                    {{-- Basic Tab --}}
                    {{-- <div class="tab-content" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="nav-home" role="tabpanel"
                            aria-labelledby="nav-home-tab">
                            <br> --}}
                            <center>
                                @if ($parameter == "front"  || $parameter == "")
                                    <label for="" class="col-sm-12 col-form-label">
                                    Velg <a href="{{url('/')}}/app?name=card">KORT </a> i menyen for å få frem ditt medlemskort.

                                    </label>
                                    <label for="" class="col-sm-12 col-form-label">
                                    For å endre ditt <a href="{{url('/')}}/app?name=hcp">HCP </a> gjøres det under Handikap i menyen.

                                    </label>
                                @elseif ($parameter == "card")
                                <div class="col-12 p-1 logo_img" >
                                    <img class="img-fluid" src="../images/card1.png">
                                
                                </div>
                                
                                <div class="col-12  form" >
                                    <table class="table table-borderless" >
                                        <tbody>
                                          <tr>
                                            <th>Name</th>
                                            <td>{{!empty($memberdata)?$memberdata->Member_Fistname . ' '. $memberdata->Member_Lastname:null}}</td>
                                          </tr>
                                          <tr>
                                            <th>Member Since</th>
                                            <td>{{!empty($memberdata->member_since)?date('m-Y', strtotime($memberdata->member_since)):null}}</td>
                                          </tr>
                                            {{-- <tr>
                                                <th></th>
                                                    <td>
                                                        <select name="" id="card_hcp_type">
                                                            <option value="online">Online</option>
                                                            <option value="manual">Manual</option>
                                                        </select>
                                                    </td>   
                                            </tr>
                                            <tr class="hcp">
                                                    <th>Current HCP</th>
                                                    <td>{{!empty($memberdata)?$memberdata->HCP:null}}
                                                    </td>
                                            </tr> --}}
                                            <tr  class="handicap">
                                                @if ($memberdata->app_hcp_status == 'manual')
                                                    <th>Current HCP</th>
                                                    <td>{{!empty($memberdata)?$memberdata->handicap:null}}</td>
                                                @else
                                                    <th>Current HCP</th>
                                                    <td>{{!empty($memberdata->new_hcp)?$memberdata->new_hcp:$memberdata->HCP}}</td>
                                                @endif
                                                
                                            </tr>
                                        </tbody>
                                       
                                      </table>
                                
                                </div>
                                <div class="col-12 p-1 logo_img" >
                                    <b style="font-weight: bold;font-size: inherit;font-family: auto;font-size: larger;">ANY COURTESIES EXTENDED TO OUR<br>MEMBER WILL BE HIGHLY APPRECIATED </b>
                                </div>
                            </center>
                            
                                @elseif ($parameter == "hcp")
                                <div id="message_updated" class="alert alert-success col-md-4  mt-2 text-center" hidden >
                                    <strong>Manuelt handikap er oppdatert!</strong> 
                                </div>
                                <strong>Her kan du oppdatere ditt handicap i medlemssystemet:</strong>
                                <div class="col-12  form2" >
                                    <center>
                                    <table class="table table-borderless" >
                                        <input type="hidden" id="manual_occid" value="{{ $memberdata->OccID }}">
                                        <tbody>
                                            <br>
                                            
                                            @if ($memberdata->OccID == '10948' || $memberdata->OccID == '10664' )
                                                <input type="hidden" id="hcp_type" name="hcp_type" value="{{ $memberdata->app_hcp_status }}">
                                                {{-- <tr>
                                                    <th>Online / Manual</th>
                                                    <td>
                                                        <select name="hcp_type" id="hcp_type">
        <option {{ ($memberdata->app_hcp_status == 'online') ? 'selected' : '' }}           value="online">Online</option>
                                                            <option {{ ($memberdata->app_hcp_status == 'manual') ? 'selected' : '' }} value="manual">Manual</option>
                                                        </select>
                                                        <span id="selected_message"       hidden>SELECTED</span>
                                                    </td>
                                                </tr> --}}
                                                @if ($memberdata->app_hcp_status == 'online')
                                                    
                                                
                                                {{-- <div id="colmun_online" hidden> --}}
                                                <tr class="colmun_online" >
                                                    <th>Occ ID</th>
                                                    <td>
                                                        <div class="col-sm-3" style="padding-left: unset;">
                                                            <input type="text" readonly="" name="OccID" class="form-control" id="OccID" placeholder="" value="{{ $memberdata->OccID }}">
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr class="colmun_online" >
                                                    <th class="th_class">Date Played</th>
                                                    <td>
                                                        <div class="col-sm-6" style="padding: unset;">
                                                        <input type="text" class="form-control"id="datepicker" value="{{ date('d-M-Y') }}">
                                                        {{-- <input type="text" id="dt2" name="date" autocomplete="off" style="width: 34%;" /> --}}
                                                            
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr class="colmun_online" >
                                                    <th>Course Played</th>
                                                    <td>
                                                        
                                                        @php
                                                        $occ_clubs = DB::table('clubs')->get();
                                                        @endphp
                                                        <select id="club" class="form-control select_club"  name="club">
                                                        <option occ-golf="" value="OCC-GOLF" selected>OCC Golf</option>
                                                        @foreach ($occ_clubs as $occ_club)
                                                        @if($occ_club->ClubName != 'OCC-GOLF')
<option >{{ $occ_club->ClubName }}</option>
                                                        @endif
                                                        @endforeach
                                                        </select>
                                                        
                                                    </td>
                                                </tr>
                                                <tr class="colmun_online" >
                                                    <th class="th_class">Current HCP</th>
                                                    <td>
                                                        <div class="col-sm-3" style="padding-left: unset;">
                                                    <input type="text" class="form-control" readonly="" id="hcpscroe" placeholder="HCP Score" value="{{ (!empty($memberdata->new_hcp ) ? $memberdata->new_hcp : $memberdata->HCP ) }}" name="hcpscroe">
    <input type="hidden" class="form-control hcp-validation" id="oldhcpscore" name="oldhcpscore" value="{{ (!empty($memberdata->new_hcp ) ? $memberdata->new_hcp : $memberdata->HCP ) }}">
                                                </div>
                                                    </td>
                                                </tr>
                                                {{-- </div> --}}

                                                <tr>
                                                    <th class="th_class">HCP Played</th>
                                                    <td>
                                                        <div class="col-sm-3" style="padding-left: unset;">
                                                        <input class=" hcp-validation form-control input_clas hcp" type="text" name="hcp_online_occid" id="hcp_online_occid"  >

                                                        
                                                        </div>
                                                        
                                                    </td>
                                                </tr>
                                                @else
                                                    <tr>
                                                        <th class="th_class">HCP Played</th>
                                                        <td>
                                                            <div class="col-sm-3"> 
                                                            <input class="hcp-validation form-control input_clas handicap" type="text" name="hcp_manual_occid" id="hcp_manual_occid"  >
                                                            </div>
                                                            
                                                        </td>
                                                    </tr>
                                                @endif
                                            @else
                                                <tr>
                                                    <th></th>
                                                    <td>
                                                        <div class="col-sm-3" style="padding-left: unset;">
                                                        <input class="form-group input_clas handicap hcp-validation" type="text" name="hcp_manual_occid" id="hcp_manual_occid" value="{{ (!empty($memberdata->handicap) ? $memberdata->handicap :'') }}" >
                                                        </div>
                                                        
                                                    </td>
                                                </tr>
                                            @endif
                                            
                                          
                                          <tr>
                                            <th></th>
                                            <td><button type="submit" id="hcp_update_manunal" class="btn btn-primary">Oppdater!</button></td>
                                          </tr>
                                         
                                        </tbody>
                                       
                                      </table>
                                </center>
                                </div>
                                
                                   {{--  <div class="col-12  form" style="    ">
                                        <div class="form-group row">
                                            <label for="name" class="col-sm-3 col-form-label "><b>Name </b>
                                            </label>
                                            <div class="col-sm-8">
                                            <label for="name"  class="col-sm-8 col-form-label labelname" >{{!empty($memberdata)?$memberdata->Member_Fistname . ' '. $memberdata->Member_Lastname:null}}</label>
                                        
                                                
                                            </div>
                                        </div>
                                    
                                        <div class="form-group row">
                                            <label for="since" class="col-sm-3 col-form-label"><b>Member Since</b>
                                            </label>
                                            <div class="col-sm-8">
                                                <label for="since" class="col-sm-8 col-form-label labelname" >{{!empty($memberdata)?$memberdata->member_since:null}}
                                                </label>
                                            
                                                
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="HCP" class="col-sm-3 col-form-label"><b>Current HCP</b>
                                            </label> 
                                            <div class="col-sm-8">
                                                <label for="since" class="col-sm-8 col-form-label labelname" >{{!empty($memberdata)?$memberdata->HCP:null}}
                                                </label>
                                            </div>
                                        </div> 

                                        
                                    </div>
                                    <div class="form-group row">
                                        <label for="quote" class="col-sm-12 col-form-label" style="text-align: center;">
                                        
                                            <b style=" 
                                            font-weight: bold;font-size: inherit;font-family: auto;">ANY COURTESIES EXTENDED TO OUR<br>MEMBER WILL BE HIGHLY APPRECIATED </b>
                                        </label>
                                        
                                    </div>--}}
                                    
                                @elseif ($parameter == "info")
                                @elseif ($parameter == "play")
                                @elseif ($parameter == "play2")
                                @elseif ($parameter == "group")
                                @elseif ($parameter == "setup")
                                    @if ($memberdata->OccID == '10948' ||$memberdata->OccID == '10664' )
                                        <div hidden id="hcp_message_updated" class="alert alert-success col-md-4  mt-2 text-center">
                                    <strong>Updated!</strong> 
                                </div >
                                <strong>Det er ingen innstillinger du kan gjøre her ennå, men det kommer!</strong>
                                         <input type="hidden" class="manual_occid" id="manual_occid" value="{{ $memberdata->OccID }}">
                                        <div class="col-12  form2" >
                                            <center>
                                                <table class="table table-borderless" >
                                                    <tr>
                                                        <th style="TEXT-ALIGN: center;padding-top: 10%;     font-family: OSWOLD;
    FONT-SIZE: larger;">Select</th>
                                                        <td>
                                                            <div class="inputGroup22">
    <input id="radio1" {{ ($memberdata->app_hcp_status == 'online' && !empty($memberdata->app_hcp_status)  ? 'checked' : '' ) }}  name="radio" type="radio" class="hcp_status" data-hcp="online"/>
    <label for="radio1">Online HCP</label>
  </div>
  <div class="inputGroup22">
    <input id="radio2" class="hcp_status" data-hcp="manual" name="radio" {{ (!empty($memberdata->app_hcp_status) && $memberdata->app_hcp_status == 'manual'  ? 'checked' : '' ) }} type="radio"/>
    <label for="radio2">Manual HCP</label>
  </div>
                                                            {{-- <select name="hcp_type" id="hcp_type">
            <option {{ ($memberdata->app_hcp_status == 'online') ? 'selected' : '' }}           value="online">Online</option>
                                                                <option {{ ($memberdata->app_hcp_status == 'manual') ? 'selected' : '' }} value="manual">Manual</option>
                                                            </select>
                                                            <span id="selected_message" hidden>SELECTED</span> --}}

                                                        </td>
                                                    </tr>
                                                </table>
                                            </center>
                                        </div>

                                    @endif
                                @elseif ($parameter == "pay")
                                @endif

                        </center>


                           
                        {{-- </div> --}}
                        {{-- Contact Tab --}}
                        {{-- <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab"> --}}
                            
                        {{-- </div> --}}
                        {{-- Member Tab --}}
                        {{-- <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab"> --}}
                            
                        {{-- </div> --}}
                        {{-- Facility Tab --}}
                        {{-- <div class="tab-pane fade" id="nav-facility" role="tabpanel" aria-labelledby="nav-contact-facility"> --}}
                            
                        {{-- </div> --}}
                        {{-- Share Tab --}}
                        {{-- <div class="tab-pane fade" id="nav-share" role="tabpanel" aria-labelledby="nav-contact-share"> --}}
                            
                          
                           
                        {{-- </div> --}}
                       
                      
                    </div>
                </div>
                
              
                   
               
                
            </div>
        </form>
            
              
            @else
                @if (empty($validate) || ($validate != "success" && $validate != "success_otp") && empty($otp_send))
                    <center>
                   

                        <form action="{{route('validate_otp')}}" method="post">
                            @if (!empty($validate) && $validate == "success")
                                <div class="alert alert-success col-md-12 offset-md-5 text-center">
                                        <strong>Suksess!</strong> 
                                    </div>
                                </div> 
                            @elseif(!empty($validate) && $validate == "check mobile")
                                <div class="form-group row mb-2">
                                    <div class="alert alert-danger col-md-12 form-group row">
                                        <strong>Fant ikke ditt mobilnummer</strong> 
                                    </div>
                                </div> 
                            @elseif(!empty($validate) && $validate == "otp not matched")
                                <div class="form-group row mb-2">
                                    <div class="alert alert-danger col-md-12 form-group row">
                                        <strong>FEIL: Engangspassordet stemmer ikke - prøv igjen</strong> 
                                    </div>
                                </div> 
                            @endif
                            @csrf
                           
                            <div class="form-group row" >
                                <div class="col-sm-2"></div>
                                <div class= "col-sm-8"style="border: solid">
                                    <div class="col-sm-12">
                                        <br>
                                       <b> Skriv inn ditt mobilnummer:</b>
                                        <br>
                                        <br>
                                    </div>
                                    <div class="col-sm-6" >
                                        <input type="text" class="form-control hcp-validation" id="mobile" value="" name="mobile" placeholder="">
                                        <br>
                                        
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="submit" value="Send engangspassord på SMS" class="btn btn-primary col-sm-12 ">
                                        
                                    </div>
                                    <br>
                                    <br>
                                </div>
                            </div>
                        </form>
                        {{-- {{!empty($validate)?$validate:null}} --}}
                    </center>
                @endif
                {{-- {{$validate}} --}}

                @if (!empty($validate) &&  ($validate == "success" || $validate=="error")  && !empty($otp_send))
                    <center>
                     
                        <form action="{{route('validate_otp')}}" method="post">
                            @if (!empty($validate) && $validate == "success")
                                {{-- <div class="alert alert-success col-md-12  text-center">
                                        <strong>Success!</strong> 
                                    </div>
                                </div>  --}}
                            @elseif(!empty($validate) && $validate == "check mobile")
                                <div class="form-group row mb-2">
                                    <div class="alert alert-danger col-md-12 form-group row">
                                        <strong>Fant ikke ditt mobilnummer</strong> 
                                    </div>
                                </div> 
                            @elseif(!empty($validate) && $validate == "otp not matched")
                                <div class="form-group row mb-2">
                                    <div class="alert alert-danger col-md-12 form-group row">
                                        <strong>FEIL: Engangspassordet stemmer ikke - prøv igjen</strong> 
                                    </div>
                                </div> 
                            @endif
                            @if (!empty($validate) && $validate == "success_otp")
                                <div class="alert alert-success col-md-4  text-center">
                                        <strong>Suksess!</strong> 
                                    </div>
                                </div> 
                            @elseif(!empty($validate) && $validate == "otp not matched")
                                <div class="form-group row mb-2">
                                    <div class="alert alert-danger col-md-10 form-group row">
                                        <strong>Vennligst sjekk SMS</strong> 
                                    </div>
                                </div> 
                            @endif
                            @csrf
                            <div class="form-group row col-12 p-3">
                                <div class="col-sm-2"></div>

                                <div class= "col-sm-8"style="border: solid">
                                    <div class="col-sm-12" style="text-align: center">
                                        <br>
                                       <b> Legg inn tilsendt engangspassord</b>
                                        <br>
                                        <br>
                                    </div>
                                    <div class="col-sm-6"  >
                                        <input type="text" class="form-control hcp-validation" id="otp" value="" name="otp" placeholder="">
                                        <input type="hidden" name="typed_mobile" value="{{!empty($mobile)? $mobile:null}}">
                                        <br>
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="submit" value="Bekreft" class="btn btn-primary col-sm-12 ">
                                        
                                    </div>
                                    <br>
                                    <br>
                                    {{-- <span class="help-block alert-primary">
                                        <strong>{{ !empty($validate)? $validate:null }}</strong>
                                    </span> --}}
                                </div>
                            </div>
                                
                                   
                              
                        </form>

                      
                    </center>
                @endif
            @endif

        </div>
        {{-- </div> --}}
        {{-- </div> --}}
    	
	</div>
	<div class="row mb-3">
		<div class="col-12 dsm">
		</div>
    </div>
    
  
</div>


        </div>
    </div>
</div>

@endsection
@push('script2')
<script>
    // $(document).ready(function() {
    //     $('#datepicker').datepicker().datepicker('setDate', 'today');
    // });
    $(document).on('click','.hcp_status',function (e) {
    //    e.preventDefault(); 
       var manual_occid = $('.manual_occid').val();
       var hcp_status = $(this).attr('data-hcp');
        // console.log(manual_occid);
        var _token = "{{ csrf_token() }}";
        $.ajax({
            url: "{{ route('update_hcp_status') }}",
            method:"POST",
            dataType:"json",
            data:{ manual_occid:manual_occid,hcp_status:hcp_status,_token:_token },
            success:function(res){
                console.log(res);
                if(res.success){
                    $('#hcp_message_updated').removeAttr('hidden');
                }
                
            }
        });

    });
    $(function() {
        select = $('#hcp_type').val();
		if(select == 'manual'){
            $('.hcp').attr('hidden',true);
            $('.handicap').removeAttr('hidden');
            $('.colmun_online').attr('hidden',true);
        }
        else if(select == 'online'){
            $('.handicap').attr('hidden',true);
            $('.hcp').removeAttr('hidden');
            $('.colmun_online').removeAttr('hidden');
        }
	});
    $(document).on('change','#card_hcp_type',function (e) {
        e.preventDefault();
        var select = $(this).val();
        console.log(select);
        if(select == 'manual'){
            
            $('.hcp').attr('hidden',true);
            $('.handicap').removeAttr('hidden');
           
        }
        else if(select == 'online'){
            $('.handicap').attr('hidden',true);
            $('.hcp').removeAttr('hidden');
            $('#selected_message').removeAttr('hidden');
        }
    });
    $(function() {
        // $("#datepicker").datepicker('setDate', 'today');
        // $('#datepicker').datepicker().datepicker('setDate', 'today');
		$( "#datepicker" ).datepicker({
            dateFormat: "dd-MM-yy",
            minDate: -30, 
            maxDate: new Date() 
        });
	});
    
    
    $(document).on('change','#hcp_type',function (e) {
        e.preventDefault();
        var select = $(this).val();
        // console.log(select);
        if(select == 'manual'){
            $('.hcp').attr('hidden',true);
            $('.handicap').removeAttr('hidden');
            $('.colmun_online').attr('hidden',true);
             $('#selected_message').removeAttr('hidden');
        }
        else if(select == 'online'){
            $('.handicap').attr('hidden',true);
            $('.hcp').removeAttr('hidden');
            $('.colmun_online').removeAttr('hidden');
             $('#selected_message').removeAttr('hidden');
        }
        var manual_occid = $('.manual_occid').val();
        // console.log(manual_occid);
        $.ajax({
            url: "{{ route('update_hcp_status') }}",
            method:"POST",
            dataType:"json",
            data:{ manual_occid:manual_occid },
            success:function(res){
                console.log(res.new_online_hcp);
                
            }
        });

    });
    $(document).on('click','#hcp_update_manunal',function (e) {
        e.preventDefault();
        var manual_occid = $('#manual_occid').val();
        var manuval_hcp = $('#hcp_manual_occid').val();
        var online_hcp = $('#hcp_online_occid').val();
        var club = $('#club').val();
        var date = $('#datepicker').val();
        var hcp_type = $('#hcp_type').val();
        console.log(hcp_type);
        var hcp_type = $('#hcp_type').val();
        var _token = "{{ csrf_token() }}";
        $.ajax({
            url: "{{ route('hcp_manuval_update') }}",
            method:"POST",
            dataType:"json",
            data:{ hcp_type:hcp_type,club:club,date:date,online_hcp:online_hcp,hcp_type:hcp_type,manuval_hcp:manuval_hcp ,_token:_token,manual_occid:manual_occid },
            success:function(res){
                console.log(res.new_online_hcp);
                if(res.success){
                    $('#message_updated').removeAttr('hidden');
                    $('#hcp_manual_occid').val(res.new_manuval_hcp);
                    $('#hcp_online_occid').val('');
                    $('#hcp_manual_occid').val('');
                    $('#hcpscroe').val(res.new_online_hcp);
                }
            }
        });
    })
</script>
@endpush