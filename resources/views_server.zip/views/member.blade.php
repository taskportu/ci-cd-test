@extends('layout')
@section('home')
@include('menu')
<div class="container">
    <div class="row text-left">
        <div class="card-body " style="padding: 0px"
            <div class="row rowsmargin">
                {{-- @if(Session::has('success')) --}}
                <div class="alert alert-success col-md-4 offset-md-5 text-center" style="display:none">
                        <strong>Saved!</strong> 
                    </div>
                {{-- @endif  --}}
                </div> 
                
                {{-- @if(Session::has('error')) --}}
                <div class="form-group row mb-2">
                    <div class="alert alert-danger col-md-10 form-group row" style="display:none">
                        <strong>OccID All ready Insert</strong> 
                    </div>
                </div> 
                {{-- @endif --}}
                <div class="class col-md-12">
                    <form method="POST" action="{{ url('add_memberdata') }}" data-submint id="newmember">
                        @csrf
                        <div class="col-md-6" style="float: left;">
                            <div class="card">
                                <h5 class="card-header h5" style="background-color: #007bff;color: white;font-size: 1.29rem;">Basic</h5>
                                <div class="card-body card-body-panel">
                                    
                                    <div class="form-group row">
                                        <label for="name" class="col-md-4 col-form-label
                                        text-md-right require_label">Member FirstName</label>
                                       
                                        <div class="col-md-6">
                                            <input id="name" type="text" class="form-control"
                                            name="MemberFistName" required >
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="name" class="col-md-4 col-form-label
                                        text-md-right require_label">Member LastName</label>
                                        <div class="col-md-6">
                                            <input id="name" type="text" class="form-control"
                                            name="MemberLastName" required >
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="OccID" class="col-md-4 col-form-label
                                        text-md-right require_label">OccID</label>
                                        <div class="col-md-3">
                                            <input id="OccID" type="text" class="form-control number_only"
                                            name="OccID" required maxlength = "5">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group row">
                                        <label for="HCP" class="col-md-4 col-form-label 
                                        text-md-right require_label">HCP Online</label>

                                        <div class="col-md-3">
                                            <input id="password" type="text" class="form-control hcp-validation" 
                                            name="HCP" required >
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="handicap" class="col-md-4 col-form-label 
                                        text-md-right">HCP Teeplay</label>
                                        <div class="col-md-3">
                                            <input id="handicap" type="text" class="form-control  hcp-validation" 
                                            name="handicap"   >
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="member_type" class="col-md-4 col-form-label 
                                        text-md-right require_label">Member Type</label>
                                        <div class="col-md-6">
                                            <select class="form-control" name="member_type" id="member_type" required>

                                                <option value="" >Select</option>
                                                <option value="Aktive">Aktive</option>
                                                <option  value="Aktiv Evigvarende">Aktiv Evigvarende</option>
                                                <option  value="Aktiv Livsvarig">Aktiv Livsvarig</option>
                                                <option value="Andel uten medlemskap">Andel uten medlemskap</option>
                                                <option value="Eldre Junior">Eldre Junior</option>
                                                <option value="Junior">Junior</option>
                                                <option value="Passiv">Passiv</option>
                                                <option value="Slettet">Slettet</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="share_type" class="col-md-4 col-form-label 
                                        text-md-right ">Share Type</label>
                                        <div class="col-md-6">
                                            <select class="form-control" name="share_type" id="share_type" >

                                                <option value="" >Select</option>
                                                <option value="A-Share">A-Share</option>
                                                <option  value="B-Share">B-Share</option>
                                                <option  value="Unknown Type">Unknown Type</option>
                                                <option value="Old Share">Old Share</option>
                                               
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="shre_number" class="col-md-4 col-form-label 
                                        text-md-right">Share Number</label>
                                        <div class="col-md-3">
                                            <input id="share_number" type="text" class="form-control  number_only" name="share_number">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {{-- upgradte --}}
                            <div class="card" style="margin-top: 10px; margin-bottom: 10px;">
                                <h5 class="card-header h5" style="background-color: #007bff;color: white;font-size: 1.29rem;">Contact</h5>
                                <div class="card-body card-body-panel">
                                    <div class="form-group row">
                                        <label for="address1" class="col-md-4 col-form-label 
                                        text-md-right">Address Line 1</label>
                                        <div class="col-md-6">
                                            <input id="address1" type="text" class="form-control" 
                                            name="address1"   >
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="address2" class="col-md-4 col-form-label 
                                        text-md-right">Address Line 2</label>
                                        <div class="col-md-6">
                                            <input id="address2" type="text" class="form-control" 
                                            name="address2"   >
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="city" class="col-md-4 col-form-label 
                                        text-md-right">City</label>
                                        <div class="col-md-5">
                                            <input id="city" type="text" class="form-control" 
                                            name="city"   >
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="zipcode" class="col-md-4 col-form-label 
                                        text-md-right">Zip Code</label>
                                        <div class="col-md-3">
                                            <input id="zipcode" type="text" class="form-control number_only" 
                                            name="zipcode"   >
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="email" class="col-md-4 col-form-label 
                                        text-md-right">Email</label>
                                        <div class="col-md-6">
                                            <input id="email" type="email" class="form-control" 
                                            name="email"   >
                                        </div>
                                    </div>
                            
                                    <div class="form-group row">
                                        <label for="tel_privately" class="col-md-4 col-form-label 
                                        text-md-right">Tel Privat</label>
                                        <div class="col-md-4">
                                            <input id="tel_privately" type="text" class="form-control number_only" 
                                            name="tel_privately"   >
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="tel_jobs" class="col-md-4 col-form-label 
                                        text-md-right">Tel Work</label>
                                        <div class="col-md-4">
                                            <input id="tel_jobs" type="text" class="form-control number_only" 
                                            name="tel_jobs"   >
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="phone_mobile" class="col-md-4 col-form-label 
                                        text-md-right">Tel Mobile</label>
                                        <div class="col-md-4">
                                            <input id="phone_mobile" type="text" class="form-control number_only" 
                                            name="phone_mobile"   >
                                        </div>
                                    </div>
                                </div>
                            </div>    
                            
                            
                            <!--<div class="form-group row">-->
                            <!--    <label for="stock_number" class="col-md-4 col-form-label -->
                            <!--    text-md-right">Stock Number</label>-->
                            <!--    <div class="col-md-6">-->
                            <!--        <input id="stock_number" type="text" class="form-control" -->
                            <!--        name="stock_number"   >-->
                            <!--    </div>-->
                            <!--</div>-->
                            <!--<div class="form-group row">-->
                            <!--    <label for="trolley_space" class="col-md-4 col-form-label -->
                            <!--    text-md-right">Trolley Space</label>-->
                            <!--    <div class="col-md-6">-->
                            <!--        <input id="trolley_space" type="text" class="form-control" -->
                            <!--        name="trolley_space"   >-->
                            <!--    </div>-->
                            <!--</div>-->
                        </div>
                        <div class="col-md-6" style="float: left;">
                            
                           <div class="card" >
                                <h5 class="card-header h5" style="background-color: #007bff;color: white;font-size: 1.29rem;">Member</h5>
                                <div class="card-body card-body-panel card-height" >
                                    <div class="form-group row">
                                        <label for="sex" class="col-md-4 col-form-label 
                                        text-md-right">Sex</label>
                                        <div class="col-md-3">
                                            {{-- <input id="sex" type="text" class="form-control" 
                                            name="sex"   > --}}
                                            <select class="form-control" name="sex">
                                                <option >Select</option>
                                                <option value="Man">Man</option>
                                                <option value="Women">Woman</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="date_of_birth" class="col-md-4 col-form-label 
                                        text-md-right">Date of Birth</label>
                                        <div class="col-md-5">
                                            <input id="date_of_birth" type="date" class="form-control" 
                                            name="date_of_birth"   >
                                            {{-- <div class="form-group">
                                                <div class='input-group date' id='datetimepicker1'>
                                                    <input type='text' class="form-control" />
                                                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span>
                                                    </span>
                                                </div>
                                            </div> --}}
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="member_since" class="col-md-4 col-form-label 
                                        text-md-right">Member Since</label>
                                        <div class="col-md-5">
                                            <input id="member_since" type="date" class="form-control" 
                                            name="member_since"   >
                                        </div>
                                    </div>
                               
                                    <div class="form-group row">
                                        <label for="resignation_date" class="col-md-4 col-form-label 
                                        text-md-right">Registration Date</label>
                                        <div class="col-md-5">
                                            <input id="resignation_date" type="date" class="form-control" 
                                        name="resignation_date" value="{{date('Y-m-d')}}"   >
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="additional_info" class="col-md-4 col-form-label 
                                        text-md-right">Additional Info</label>
                                        <div class="col-md-6">
                                            <!--<input id="additional_info" type="text" class="form-control" -->
                                            <!--name="additional_info"   >-->
                                            <textarea name="additional_info" id="" cols="30" rows="3"></textarea>
                                        </div>
                                    </div>
                                </div>
                           </div>
                            <!--<div class="form-group row">-->
                            <!--    <label for="family_head" class="col-md-4 col-form-label -->
                            <!--    text-md-right">Family Head</label>-->
                            <!--    <div class="col-md-6">-->
                            <!--        <input id="family_head" type="text" class="form-control" -->
                            <!--        name="family_head"   >-->
                            <!--    </div>-->
                            <!--</div>-->
                            <!--<div class="form-group row">-->
                            <!--    <label for="family_head_name" class="col-md-4 col-form-label -->
                            <!--    text-md-right">Family Head Name</label>-->
                            <!--    <div class="col-md-6">-->
                            <!--        <input id="family_head_name" type="text" class="form-control" -->
                            <!--        name="family_head_name"   >-->
                            <!--    </div>-->
                            <!--</div>-->
                            <!--<div class="form-group row">-->
                            <!--    <label for="family_head_no" class="col-md-4 col-form-label -->
                            <!--    text-md-right">Family Head No</label>-->
                            <!--    <div class="col-md-6">-->
                            <!--        <input id="family_head_no" type="number" class="form-control" -->
                            <!--        name="family_head_no"   >-->
                            <!--    </div>-->
                            <!--</div>-->
                            <!--<div class="form-group row">-->
                            <!--    <label for="shareholder_name" class="col-md-4 col-form-label -->
                            <!--    text-md-right">Shareholder Name</label>-->
                            <!--    <div class="col-md-6">-->
                            <!--        <input id="shareholder_name" type="text" class="form-control" -->
                            <!--        name="shareholder_name"   >-->
                            <!--    </div>-->
                            <!--</div>-->
                            <!--<div class="form-group row">-->
                            <!--    <label for="shareholder_member_no" class="col-md-4 col-form-label -->
                            <!--    text-md-right">Shareholder Member No</label>-->
                            <!--    <div class="col-md-6">-->
                            <!--        <input id="shareholder_member_no" type="text" class="form-control" -->
                            <!--        name="shareholder_member_no"   >-->
                            <!--    </div>-->
                            <!--</div>-->
                            <div class="card" style="margin-top: 10px;">
                                <h5 class="card-header h5" style="background-color: #007bff;color: white;font-size: 1.29rem;">Facilities</h5>
                                <div class="card-body card-body-panel" style="height: 470px;">
                                    <div class="form-group row">
                                        <label for="wardrobe" class="col-md-4 col-form-label 
                                        text-md-right">Wardrobe</label>
                                        <div class="col-md-2">
                                            <input id="wardrobe" type="text" class="form-control" 
                                            name="wardrobe"   >
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="drinks_cabinet" class="col-md-4 col-form-label 
                                        text-md-right">Drinks Cabinet</label>
                                        <div class="col-md-2">
                                            <input id="drinks_cabinet" type="text" class="form-control" 
                                            name="drinks_cabinet"   >
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="stick_cabinet" class="col-md-4 col-form-label 
                                        text-md-right">Stick Cabinet</label>
                                        <div class="col-md-2">
                                            <input id="stick_cabinet" type="text" class="form-control" 
                                            name="stick_cabinet"   >
                                        </div>
                                    </div>
                                    <!--<div class="form-group row">-->
                                    <!--    <label for="car" class="col-md-4 col-form-label -->
                                    <!--    text-md-right">Car</label>-->
                                    <!--    <div class="col-md-6">-->
                                    <!--        <input id="car" type="text" class="form-control" -->
                                    <!--        name="car"   >-->
                                    <!--    </div>-->
                                    <!--</div>-->
                                    <div class="form-group row">
                                        <label for="charging_site" class="col-md-4 col-form-label 
                                        text-md-right">Charging Site</label>
                                        <div class="col-md-2">
                                            <input id="charging_site" type="text" class="form-control" 
                                            name="charging_site"   >
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="trolley_space" class="col-md-4 col-form-label 
                                        text-md-right">Trolley Space</label>
                                        <div class="col-md-2">
                                            <input id="trolley_space" type="text" class="form-control" 
                                            name="trolley_space"   >
                                        </div>
                                    </div>
                                    {{-- <div class="form-group row">
                                        <label for="HCP" class="col-md-4 col-form-label 
                                        text-md-right">
                                        Playing Eligibility</label>
                                        <div class="col-md-6">
                                            <label class="containerqq">
                                                <input type="radio" name="playing_eligibility"  value="yes">
                                                <span class="checkmark"></span>
                                                </label>
                                                <label class="containerqq">
                                                <input type="radio" name="playing_eligibility" value="no">
                                                <span class="checkmark"></span>
                                            </label>
                                        </div>
                                    </div> --}}
                                </div>
                            </div>
                            {{-- upgradtion end --}}
                            <div class="form-group row mb-0">
                                {{-- <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary" id="submit" style="margin-top: 19px;">
                                    Add
                                    </button>
                                </div> --}}
                                <div class="center col-11">
                                    <p class="float-sm-right pcursor" style="">
                                        <button type="submit" id="submit" class="btn btn-primary" style="margin-top: 10px;font-size: 1.29rem;height: 45px;">Add</button>
                                    </p>
                                    
                                </div>
                            </div>
                        </div>
                    </form> 
                </div>
            </div>
            <div class="col-md-6">
                            
            </div>
            {{-- <div class="form-group row mb-2">
                @if(Session::has('success'))
                    <div class="alert alert-success col-md-4 offset-md-5 text-center">
                        <strong>Saved!</strong> 
                    </div>
                @endif 
                </div> 
                
                @if(Session::has('error'))
                <div class="form-group row mb-2">
                    <div class="alert alert-danger col-md-10 form-group row">
                        <strong>OccID All ready Insert</strong> 
                    </div>
                </div> 
                @endif
           
            </div>     --}}
        </div>
    </div>
 </div>           

<!--<div class="container">
	<div class="row mt-3 text-left">
        <table class="table table-bordered">
          <thead>
            <tr>
              
                  
                  <th scope="col">MemberName</th>
                  <th scope="col">OccID</th>
                  <th scope="col">HCP</th>
                  <th scope="col"></th>
            </tr>
          </thead>
          <tbody>
          @foreach( $membername as $data)
            <tr>
                  <td>{{$data->MemberName}}</td>
                  <td>{{$data->OccID}}</td>
                  <td>{{$data->HCP}}</td>
                  <td><button type="button" class="btn btn-danger">Delete</button></td>
            </tr>
          @endforeach 
          </tbody>
        </table>
   </div> 
</div>-->
@endsection
@push('style')
    <style>
        @media (min-width: 320px) and (max-width: 480px) {
            .card-height{
                height:auto !important;
            }
        }
        .card-height{
            height: 412px;
        }
        .require_label:after {
            content:"*";
            color:red;
        }
        .card-body-panel{
            background-color: #007bff05 !important;
        }
        .rowsmargin{
            margin-top: 20px;
        }
        .well {
            min-height: 20px;
            padding: 19px;
            margin-bottom: 20px;
            background-color: #f5f5f5;
            border: 1px solid #e3e3e3;
            border-radius: 4px;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .05);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .05)
        }

        .well blockquote {
            border-color: #ddd;
            border-color: rgba(0, 0, 0, .15)
        }

        .well-lg {
            padding: 24px;
            border-radius: 6px
        }

        .well-sm {
            padding: 9px;
            border-radius: 3px
        }
        .btn span.glyphicon {    			
            opacity: 0;				
        }
        .btn.active span.glyphicon {				
            opacity: 1;				
        }
        .input-group-addon {
            padding: 6px 12px;
            font-size: 14px;
            /* font-weight: 400; */
            line-height: 1;
            color: #555;
            text-align: center;
            background-color: #eee;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        /* The container */
        .containerqq {
        /* display: block; */
        position: relative;
        padding-left: 35px;
        margin-bottom: 12px;
        margin-left: 13px;
        cursor: pointer;
        font-size: 17px;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;

        }

        /* Hide the browser's default checkbox */
        .containerqq input {
        position: absolute;
        opacity: 0;
        cursor: pointer;
        height: 0;
        width: 0;
        }

        /* Create a custom checkbox */
        .checkmark {
        position: absolute;
        top: 0;
        left: 0;
        height: 33px;
        width: 36px;
        background-color: #eee;
        }

        /* On mouse-over, add a grey background color */
        .containerqq:hover input ~ .checkmark {
        background-color: #ccc;
        }

        /* When the checkbox is checked, add a blue background */
        .containerqq input:checked ~ .checkmark {
            background-color: #2196F3;
        }

        /* Create the checkmark/indicator (hidden when not checked) */
        .checkmark:after {
        content: "";
        position: absolute;
        display: none;
        }

        /* Show the checkmark when checked */
        .containerqq input:checked ~ .checkmark:after {
        display: block;
        }

        /* Style the checkmark/indicator */
        .containerqq .checkmark:after {
            left: 15px;
            top: 7px;
            width: 7px;
            height: 16px;
            border: solid white;
            border-width: 0 3px 3px 0;
            -webkit-transform: rotate(45deg);
            -ms-transform: rotate(45deg);
            transform: rotate(45deg);
        }
    </style>
@endpush
@push('script2')
    
   <script>
        
        $(document).on('click','input[name="playing_eligibility"]',function () { 
            var th = $(this).val();
            if(th == "yes")
            {
                $('.checkmark').removeAttr('style');
                $('.containerqq:hover input ~ .checkmark').css('background-color','#0da74e');
            }
            else
            {
                $('.checkmark').removeAttr('style');
                $('.containerqq:hover input ~ .checkmark').css({'background-color':'#f13f0f'});
            }
            
        });

        $('#newmember').submit(function(e)
        {
            e.preventDefault();
            var OccID = $('#OccID').val();
            var _token = "{{csrf_token()}}";
            var url = "{{url('member/add')}}"
            $.ajax({
                url:"{{ route('check_member') }}",
                method:"POST",
                data:{_token:_token,OccID:OccID},
                success:function(res){
                    // console.log(res.last_names);
                    // console.log(res.first_names[0]);
                    // var x = res.first_names;
                    // var nameArr = .split(',');
                    // console.log(nameArr);
                   
                    console.log(x)
                    if(res.message == "alert")
                    {
                        var x = '';
                        for (let index = 0; index < res.first_names.length; index++) {
                            const element = res.first_names[index];
                            // console.log(element);
                            x = x + '<li>'+element+'</li>';
                        }
                        $.confirm({
                            // title: 'Make Old!!',
                            // content: 'Are you sure you want to make '+ res.first_names + ' as an old member?' ,
                            title: 'Are you sure you want to make as an old member?' ,
                            content: x,
                            // autoClose: 'cancelAction|8000',
                            buttons: {
                                OK: {
                                    text: 'Yes',
                                    btnClass: 'btn-red',
                                    width : 500,
                                    action: function () {
                                        var data = $('#newmember').serialize();
                                        var _token = "{{ csrf_token() }}";
                                        $.ajax({
                                            url:"{{ route('add_memberdata') }}",
                                            method:"POST",
                                            data:data,
                                            dataType: "json",
                                            success:function(res){
                                                // console.log(res);
                                                if(res.success)
                                                {
                                                    $('.alert-success').css('display','block');
                                                    setTimeout(function(){
                                                        location.reload(true);
                                                    }, 2000);  
                                                }
                                                else
                                                {
                                                    $('.alert-danger').css('display','block');
                                                    setTimeout(function(){
                                                        location.reload(true);
                                                    }, 2000);  
                                                   
                                                }
                                               
                                                
                                            }
                                        });
                                    }
                                },
                                cancelButton: {
                                    text:'No',
                                    action:function () {
                                        
                                    }
                                },
                                // cancelAction: function () {
                                // 	$.alert('action is canceled');
                                // }
                            }
                        })
                    }
                    else if(res.message == "submit")
                    {
                        var data = $('#newmember').serialize();
                        var _token = "{{ csrf_token() }}";
                        $.ajax({
                            url:"{{ route('add_memberdata') }}",
                            method:"POST",
                            data:data,
                            dataType: "json",
                            success:function(res){
                                console.log(res)
                                if(res.success)
                                {
                                    $('.alert-success').css('display','block');
                                    setTimeout(function(){
                                        location.reload(true);
                                    }, 2000);  
                                }
                                else
                                {
                                    $('.alert-danger').css('display','block');
                                    setTimeout(function(){
                                        location.reload(true);
                                    }, 2000);  
                                    
                                }
                                
                                
                            }
                        });
                    }
                    
                    
                }
            });
        })
    </script>
@endpush