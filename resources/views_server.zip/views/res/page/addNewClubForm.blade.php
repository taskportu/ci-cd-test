<div class="row">
	<form class="col-12" action="res/createClub" method="post" data-log=".gc-rnm">  
    	<div class="row">
        	<div class="col-12">
            </div>
        </div>  	
        <div class="row">
        	<div class="col-12">
            	<h5 class="pt-2 pb-2">
                    New club
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </h5>
            </div>
        </div>
        <div class="row">
        	<div class="col-12 mb-2">
            	<input type="text" class="form-control" placeholder="Occ ID">
            </div>
        	<div class="col-12 mb-2">
            	<input type="text" class="form-control" placeholder="Club name">
            </div>
            <div class="col-12">
            	<div class="row">
            		<div class="col-12 gc-rnm"></div>
                </div>
            </div>
            <div class="col-12">
                <div class="row mb-2">
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary float-right">Create</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>