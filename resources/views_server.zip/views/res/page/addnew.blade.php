<div class="row">
	<div class="col-12">
    	<div class="row">
        	<div class="col-12">
            	<h5>addnew</h5>
            </div>
        </div>
        <div class="row">
        	<!--<div class="col-12">
            	<div class="row">
                	<div class="col-sm-6 text-right"><span class="gc-help">Help</span></div>
                	<div class="col-sm-6">F1 / Alt + H</div>
                </div>
            	<div class="row">
                	<div class="col-sm-6 text-right"><span class="gc-help">Quick find</span></div>
                	<div class="col-sm-6">F2 / Ctrl + F</div>
                </div>
            	<div class="row">
                	<div class="col-sm-6 text-right"><span class="gc-help">New member</span></div>
                	<div class="col-sm-6">F5 / Alt + M</div>
                </div>
            	<div class="row">
                	<div class="col-sm-6 text-right"><span class="gc-help">New club</span></div>
                	<div class="col-sm-6">F6 / Alt + L</div>
                </div>
            </div>-->
        </div>
    </div>
</div>
