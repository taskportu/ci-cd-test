<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Document</title>
  </head>
  <body>
    <p>Kjære medlem!</p>
    <p>Dette er kun til informasjon:</p>
    <p>Ditt HCP i OCC's medlemssystem er oppdatert til: {{ $new_hcp }}</p>
    <p>Du finner ditt digital medlemskort på app.occ.no</p>
    <p>Du er register med følgende mobil {{ $member_phoneno }} soom benyttes ved pålogging.</p>
    <p>Skulle endringen ikke stemme venligst ta kontakt med occ@occ.no</p>
    <p>Med ønske om en strålende golf dag!</p>
    <p>Mvh</p>
    <p>OCC</p>
  </body>
</html>
