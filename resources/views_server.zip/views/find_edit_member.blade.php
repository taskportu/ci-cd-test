@extends('layout')
@section('home')
@include('menu')

<div class="col-sm-6 pt-5 mt-5 mx-auto"><h5 class="text-center mb-3">Edit/Delete member</h5>
        	<div class="input-group">
                <input type="text" class="form-control p-2 gc-homesearch" name="editmember" placeholder="">
                <button class="btn btn-dark pl-2 pr-2">
                	<span class="glyphicon glyphicon-search"></span>
                </button>
            </div>
           <div class="replay_edit_member">
           </div>
           
		</div>
        
@endsection