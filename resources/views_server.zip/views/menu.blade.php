<div class="container-fluid">
	<div class="row">
		<div class="col-12">
            <a href="{{ url('/admin') }}" class=""><span style="font-size: 35px; font-weight: 500; "> HOME</span></a>
        	<a href="{{ url('/') }}" class=""><span>REGISTRATION</span></a>
            @if(Session::has('authenticated'))
            <span>*</span><span style="font-size:16px;"><a href="{{ url('adminlogout') }}" class="" >LOGOUT</a></span>
            @endif
            </h5>
        </div>
		<div class="col-12">
        	<span>MEMBER : </span>
            <a href="{{url('member/add')}}">ADD</a>
            <span>*</span>
            <a href="{{url('member/find_edit_member')}}">EDIT</a>
            <span>*</span>
            <a href="{{url('member/club')}}">CLUB</a>
            <!--<span>*</span>-->
            <!--<a href="#">PURCHASE</a>-->
		</div>
        <div class="col-12">
        	<span>REPORT :</span>
            <a href="{{ url('report/now') }}">NOW</a>
            <span>*</span>
            <a href="{{ url('report/today') }}">TODAY</a>
            <span>*</span>
            <a href="{{ url('report/week') }}">WEEK</a>
            <span>*</span>
            <a href="{{ url('report/month') }}">MONTH</a>
            <span>*</span>
            <a href="{{url('report/guest')}}">GUEST</a>
             <span>*</span>
            <a href="{{ url('report/activity') }}">ACTIVITY</a>
            <span>*</span>
            <a href="{{ route('report_search') }}">SEARCH</a>
            
        </div>
	</div>
</div>