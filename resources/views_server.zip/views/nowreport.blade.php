@extends('layout')
@section('home')
@include('menu')

<style>
#voo {background-color: #ffffb2;}

</style>
<div class="container">
    <h3 class="text-center">Now</h3>
  <div class="rows mt-4" >

    <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">MemberID</th>
      <th scope="col">Name</th>
      <th scope="col">Time</th>
    </tr>
  </thead>
  <tbody>
  	@php
    	$count = $report->count();
    @endphp
    @if($report->isNotEmpty())
      	@foreach($report as $m)
        @php
            $guest = App\Reg::where('reg_guest_member',$m->reg_auto)
            ->get();
        @endphp        
        <tr>
      		<td>{{ $m->OccID }}</td>
      		<td>{{ $m->Member_Fistname }} {{ $m->Member_Lastname }}</td>
      		<td>{{ date('H:i', strtotime($m->reg_time)) }}</td>
        </tr>
        	@if($guest->isNotEmpty())
            @foreach($guest as $g)
            @php $count++ @endphp
       	<tr bgcolor="#ffffb2 "  id="voo">
      		<td data-toggle="tooltip"  data-html="true" data-placement="top" title="Club -{{$g->reg_club}} 
            <br> HCP - {{$g->reg_hcp}} <br> Tlf - {{$g->reg_phone}}">Guest</td>
      		<td  data-toggle="tooltip"  data-html="true" data-placement="top" title="Club -{{$g->reg_club}} <br>
             HCP - {{$g->reg_hcp}} <br> Tlf - {{$g->reg_phone}}">{{ucfirst( $g->reg_fistname)}} {{ucfirst($g->reg_lastname)}}</td>
      		<td  data-toggle="tooltip"  data-html="true" data-placement="top" title="Club -{{$g->reg_club}} <br> 
            HCP - {{$g->reg_hcp}} <br> Tlf - {{$g->reg_phone}}">{{ date('H:i', strtotime($g->reg_time)) }}</td>
        </tr>
      
  
            @endforeach
        	@endif
            
            @if($count == 75)
            @php break; @endphp
            @endif
      	@endforeach
    @endif
  </tbody>
</table>
  </div>
</div>

@endsection
