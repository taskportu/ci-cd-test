@extends('layout')
@section('home')
	@include('menu')

	
<style>
	#voo {background-color: #ffffb2;}
	
	</style>
	<div class="container">
		{{-- <h3 class="text-center">Status</h3> --}}
	  <div class="rows mt-4" >
	
		<table class="table table-bordered " style="width:50%; margin: 25%;
		margin-top: 0%;     margin-bottom: 0%;" >
			<thead style="text-align: center;">
				<tr>
                    <th scope="col">Member ID</th>
					<th scope="col">Phone</th>
					<th scope="col">Email</th>
					<th scope="col">Count</th>
                    
					<th scope="col">Date</th>
                    <th scope="col">SMS/Email</th>
                    <th scope="col">Code</th>
					
                    
				</tr>
			</thead>
			<tbody >
				@foreach ($trackings as $key=>$tracking)
					<tr>
						<td>
							{{$tracking->member_id}}
						</td>
						<td>
							{{$tracking->phone}}
                        </td>
                        <td>
							{{$tracking->email}}
                        </td>
                        <td>
							{{$tracking->count}}
                        </td>
                        <td>
							{{$tracking->date}}
						</td>
						<td>
							S
						</td>
						<td>
							{{ $tracking->code }}

						</td>
					</tr>
				@endforeach
				
			</tbody>
		</table>
	  </div>
	</div>
@endsection
