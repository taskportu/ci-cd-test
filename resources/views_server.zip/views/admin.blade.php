@extends('layout')
@section('home')
	@include('menu')

	
<style>
	#voo {background-color: #ffffb2;}
	
	</style>
	<div class="container">
		{{-- <h3 class="text-center">Status</h3> --}}
	  <div class="rows mt-4" >
	
		<table class="table table-bordered " style="width:50%; margin: 25%;
		margin-top: 0%;     margin-bottom: 0%;" >
			<thead style="text-align: center;">
				<tr>
					<th scope="col">Member Type</th>
					<th scope="col">Counted</th>
					<th scope="col">Unique Email </th>
				</tr>
			</thead>
			<tbody >
				@foreach ($status as $key=>$statu)
					<tr>
						<td style="{{ ($key == 'Total Sum' ? "font-weight: bold;" : '' ) }}">
							{{$key}}
						</td>
						<td style="{{ ($key == 'Total Sum' ? "font-weight: bold;" : '' ) }}">
							{{ $statu}}
						</td>
						<td style="{{ ($key == 'Total Sum' ? "color: white;" : '' ) }}"> {{ ( $key = $email_counts[$key] ? $email_counts[$key] : ''  ) }}</td>
					</tr>			
					
				@endforeach
				
			</tbody>
		</table>
	  </div>
	</div>
@endsection
