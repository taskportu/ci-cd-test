@extends('layout')
@section('home')
<div class="container-fluid">
	<div class="row">
    <div class="col-12 ">
   

  
 
 @if((Session::get('user')=='user') and (Session::get('authenticated')==''))
 	 <a href="{{ url('adminlogout') }}"  class="gc-help" >LOGOUT<!-- <span class="gc-sc"> (F5)</span>--></a></h3>
 @else
 <h3><a href="{{ url('admin') }}"  class="gc-help" >ADMIN<!-- <span class="gc-sc"> (F5)</span>--></a>
    <span style="font-size: 15px;">|</span>
    <a href="{{ url('adminlogout') }}"  class="gc-help" >LOGOUT<!-- <span class="gc-sc"> (F5)</span>--></a></h3>

 @endif


    <div class="container">
	<div class="row mb-2">
    	<div class="col-12 p-3">
    		
    		<center>
                  <img class="img-fluid" src="../images/banner.jpg">
              </center>	
    	</div>
    	<div class="col-md-8 col-xs-12 pt-5 mt-5 mx-auto">
        	<div class="input-group">
                <input type="text" class="form-control p-2 gc-homesearch" placeholder="Søk opp medlem" id="findMembers">
                <button class="btn btn-secondary pl-2 pr-2">
                	<span class="glyphicon glyphicon-search"></span>
                </button>
            </div>
            <!--<span class="gc-sc float-right">help F1</span>-->
		</div>
	</div>
	<div class="row mb-3">
		<div class="col-12 dsm">
		</div>
	</div>
    <div class="row">
    	<div class="col-8 mx-auto gc-help gc-rmt">
          	<div class="row mb-2">
          		 <div class="col-12">
                    <div class="mltr">
                    	 <div class="row">
                            <div class="col-sm-9">
                                <div class="row">
                                    <div class="col-2">Medl.ID</div>
                                    <div class="col-10">
                                    	<div class="row">
                                            <div class="col-4">Navn</div>
                                            <div class="col-6">Klubbnavn</div>
                                            <div class="col-2 text-right">HCP</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                &nbsp;
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    	<div class="col-8 mx-auto wfr">
        </div>
        <div class="col-8 mx-auto">
        	<div class="row">
        		<div class="col-12">

                	<div class="gcmrb text-right">
                		<button class="btn btn-secondary gc-btn mt-2" onClick="register()">Registrer</button>
                    </div>
                    <center>
                    <table border="1">
                    	<br><br><br>
                    	<tr><td>                    		                    		

                    		<b>SLIK VIRKER DETTE:</b>
                    		<br><br>
 - Dette er kun for å registrere deg som medlem spiller i dag og evt. gjester du har med<br>
 - Registreringen angir ikke når du får spille (bruk ballrenne) eller med hvem<br>
 - Skrive inn deler av ditt navn og klikk på deg selv når det kommer opp på søkelisten<br>
 - Du kan velge flere som spiller sammen med deg, men det er ikke nødvendig<br>
 - Har du med gjester registreres de under det medlem som har invitert de (Gjest)<br>
 - Gjester registreres med mobilnummer - du kan legge til flere gjester under et medlem<br>
 - Finner du ikke klubben gjesten tilhører på listen så skriv inn klubbens navn i feltet<br>
 - Alle medlemmers HCP er satt til 15 - oppdaterer i skjema før du velger å registrere<br>
<br>
<center>
NÅR ALLE SPILLERE ER LAGT TIL PÅ LISTEN SÅ TRYKK REGISTRER<br>
(glemte du å få med noen er det bare å starte på nytt)<br>
</center>




                    	</td></tr>
                    </table>	
                </center>
                </div>
            </div>
        </div>
    </div>
</div>

   <!--<span class="gc-help">New</span> |-->
					
        	<!--<a href="#" id="addNewMember" onClick="getNewMemberForm()" class="gc-help"><span class="gc-alt">M</span>ember <span class="gc-sc"> (F5)</span></a> |
        	<a href="#" id="addNewClub" onClick="getNewClubForm()" class="gc-help">C<span class="gc-alt">l</span>ub<span class="gc-sc"> (F6)</span></a> |
        	<a href="#" id="addNewClub" onClick="getHelp()" class="gc-help"><span class="gc-alt">H</span>elp <span class="gc-sc"> (F1)</span></a> |-->
        </div>
    </div>
</div>

@endsection
