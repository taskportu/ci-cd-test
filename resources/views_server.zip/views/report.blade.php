@extends('layout')
@section('home')
	@include('menu')
<div class="container">
</div>
@endsection
